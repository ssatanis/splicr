# SplicR recorded-results export

Exported: 2026-10-08T15:39:06.192Z

Each screen folder contains individually usable gene-results.csv and screen.json.
Selected evidence sections have separate CSV files. When Run provenance is
selected, analysis-settings.json preserves the recorded run settings and versions.
methods_text.txt supplies a methods draft for author review, and
methods-record.json retains its exact execution evidence. Completed methods
come from the completed hit-calling stage, not from the requested caller list.
Unknown tool versions and effective parameters remain explicitly unrecorded.
Missing settings are null, not a reconstruction of what the engine probably used.
manifest.json records screen/run identities, comparison IDs, row counts, selected
columns, filters, section selection, and the size and SHA-256 of every other file.
data-dictionary.csv explains the selected gene-result columns.

Extract the complete ZIP, then run Python 3.9 or newer:

    python3 verify-bundle.py

The check streams each listed file, detects missing or changed bytes, and does not
require SplicR, credentials, or internet access. manifest.json is excluded from its
own inventory to avoid a circular checksum. These hashes do not authenticate the
manifest or author, verify biological conclusions, or prove reproducible execution.
Unlisted files are not verified. Keep the original download for comparison.

Statistics are recorded outputs; exporting does not rerun an analysis. Zero,
missing values, and no rows have different meanings. Check recorded_gene_rows,
exported_gene_rows, and selection in manifest.json before interpreting empty tables.
QC verdicts and artifact flags remain applicable when filtering to selected genes.
An uncalibrated model score is not a validation probability.

CSV text beginning with spreadsheet formula characters has an apostrophe prefix.
For exact original text use JSON; for typed gene symbols use the Excel export.
When importing CSV into Excel, set gene_symbol and all identifiers to Text so
date-like gene symbols are not rewritten. CSV numbers retain recorded precision.
When moving a table individually, include its screen.json and data-dictionary.csv
to retain run identity and column meaning.

This is a recorded-results bundle. Raw uploads, notebooks, discussion snapshots,
figure source data, and a locked executable environment are not included.
It is not a certified RO-Crate, Workflow Run Crate, or BagIt package.
